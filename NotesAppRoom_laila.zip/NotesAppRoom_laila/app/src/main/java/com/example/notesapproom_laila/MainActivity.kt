package com.example.notesapproom_laila

import android.app.AlertDialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Adapter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView
    lateinit var EditText_add_Name: EditText
    lateinit var Button_Save: Button

    var s1 =""
    var Note_List = arrayListOf<Table_Notes>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        Button_Save = findViewById(R.id.Button_Save)
        Recycler_View = findViewById(R.id.Recycler_View)

        NotesDatabase.getInstance(applicationContext)

        update_Recycler_View()

        Button_Save.setOnClickListener {
            val note = EditText_add_Name.text.toString()
            val noteOBJ = Table_Notes(0, note)
            CoroutineScope(Dispatchers.IO).launch {
                NotesDatabase.getInstance(applicationContext).NotesDao().insertNote(noteOBJ)
                withContext(Dispatchers.Main) {
                    adapter_list(NotesDatabase.getInstance(applicationContext).NotesDao().getAllNotes())
                }
            }
            EditText_add_Name.setText("")
        }
    }

    private fun adapter_list(list: List<Table_Notes>){
        Recycler_View.adapter = Adapter(this,list)
        Recycler_View.layoutManager = LinearLayoutManager(this)
    }

    fun update_Recycler_View(){

        CoroutineScope(Dispatchers.IO).launch {

            var Note_List = NotesDatabase.getInstance(applicationContext).NotesDao().getAllNotes()
            adapter_list(Note_List)

        }
    }

    fun Update( id_Update: Int){
        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this)
        val dialogView =
            LayoutInflater.from(this).inflate(R.layout.activity_update, null)
        dialogBuilder.setView(dialogView)
        val Update_Note = EditText(this)
        var Note = ""
        dialogBuilder.setMessage("")
            .setPositiveButton("Update", DialogInterface.OnClickListener {
                    _, _ ->  Note = Update_Note.text.toString()
                Toast.makeText(applicationContext, "$id_Update", Toast.LENGTH_SHORT).show()
                CoroutineScope(Dispatchers.IO).launch {
                    NotesDatabase.getInstance(applicationContext).NotesDao().updateOBJ(Table_Notes(id_Update,Note))
                    withContext(Dispatchers.Main) {
                        adapter_list(NotesDatabase.getInstance(applicationContext).NotesDao().getAllNotes())
                    }
                }
            })
            .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                    dialog, _ -> dialog.cancel()
            })
        val alertDialog = dialogBuilder.create()
        alertDialog.setTitle("Update Note $id_Update")
        alertDialog.setView(Update_Note)
        alertDialog.show()


    }

    fun Delete( id_delete: Int , name_delete: String){
        val dialogBuilder = androidx.appcompat.app.AlertDialog.Builder(this)


        dialogBuilder.setMessage("Are you sure you want to delete Note $id_delete?")
            .setPositiveButton("Delete", DialogInterface.OnClickListener {
                    dialog, id ->

                CoroutineScope(Dispatchers.IO).launch { NotesDatabase.getInstance(applicationContext).NotesDao()
                    .deleteOBJ(Table_Notes(id_delete,name_delete))
                    withContext(Dispatchers.Main) {
                        adapter_list(NotesDatabase.getInstance(applicationContext).NotesDao().getAllNotes())
                    }
                }
            })
            .setNegativeButton("Cancel", DialogInterface.OnClickListener {
                    dialog, id -> dialog.cancel()
            })
        val alertDialog = dialogBuilder.create()
        alertDialog.setTitle("Delete Note $id_delete")
        alertDialog.show()


    }

}