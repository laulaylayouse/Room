package com.example.notesapproom_laila

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_row.view.*

class Adapter (private val MainActivity: MainActivity, private val messages: List<Table_Notes>):
    RecyclerView.Adapter<Adapter.ItemViewHolder>(){
    class ItemViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        var message = messages[position]

        holder.itemView.apply {

            TextView_Name.text = message.name
            ImageView_Update.setOnClickListener {

                var id_Update = message.id
                MainActivity.Update(id_Update)

            }
            ImageView_delete.setOnClickListener {

                var id_delete = message.id
                var name_delete = message.name
                MainActivity.Delete(id_delete,name_delete)
            }

        }
    }

    override fun getItemCount()= messages.size
}

