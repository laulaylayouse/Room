package com.example.notesapproom_laila

import androidx.room.*


@Dao
interface NotesDao{

    @Query("SELECT * FROM Notes")
    fun getAllNotes(): List<Table_Notes>

    @Insert
    fun insertNote(notes: Table_Notes)

    @Query("DELETE FROM Notes where id=:pk")
    fun deleteNote(pk: Int)

    @Query("UPDATE Notes SET Note=:note where id=:pk")
    fun updateNote(note: String,pk: Int)

    @Delete
    fun deleteOBJ(note: Table_Notes)

    @Update
    fun updateOBJ(note: Table_Notes)

}